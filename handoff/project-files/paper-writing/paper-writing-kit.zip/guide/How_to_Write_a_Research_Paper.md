---
title: "How to Write a Research Paper"
subtitle: "A working guide merged from three talks on paper writing"
---

# How to write a research paper

This guide merges the writing advice from three talks: Simon Peyton Jones's Microsoft Research lecture *How to Write a Great Research Paper*, and two YouTube videos, *How to Get More Citations* and *Why Your Research Paper Feels So Hard*. I kept only the advice about writing and left out the anecdotes. Where the talks disagree, I say so and give the rule this guide follows. Section 11 lists those conflicts in one place.

The guide follows the order you write a paper in, which is different from the order a reader reads it in.

## 1. What a paper is for

A paper exists to move one idea from your head into the reader's head, clearly enough that they can use it. Three common reasons for writing are weak ones. Impressing people is one. Reporting what you did over the past year is another, because readers care about what they can take away, not about your year. The third is describing a system or result only because it is new. Novelty alone is a thin reason to read. Fred Brooks put it this way in *The Computer Scientist as Toolsmith*: a toolmaker succeeds when the users of the tool succeed. Ask what a reader can do after reading your paper that they could not do before.

Two rules follow from this.

First, write about one idea. If you have ten ideas, you probably have several papers. Before drafting, finish this sentence: "The main idea of this paper is ___." If you cannot finish it, the reader will not be able to either. The idea may only become clear while you write, and that is normal, but it has to be clear by the time you submit.

Second, decide on the story early. One of the talks says the narrative matters more than the list of results. A simple narrative has three parts: background, problem, and solution. Frame your gap as a problem that hurts someone. "Nobody has studied X" is a weak gap. "X fails in this specific way, and here is the cost" is a strong one.

## 2. When to start writing

Start writing early, before the research is finished. Peyton Jones argues that the paper works as a forcing function. Once you try to write section 3, you find out that a proof is missing or an experiment was never run, and you find out months before the deadline instead of two weeks before it. Writing also shows you what you do not yet understand. If a paragraph keeps growing caveats, the idea underneath it is not settled.

You do not need a great idea to start. Start a paper whenever you have any idea, however small. Small ideas often turn out to be more interesting once you write them down, and the practice makes you better at writing the big paper later. Importance is usually something you discover afterwards.

## 3. The order to write the sections in

All three talks agree that you should not write a paper top to bottom. The two videos give a concrete backwards order, and Peyton Jones adds one thing to do first. Combined, the order is:

1. **The one-sentence idea and the list of contributions.** Write these first and treat them as the specification for the paper. You will revise them as you go.
2. **Figures.** Make them and put them in an order that tells the story (section 4).
3. **Results.** Describe what each figure shows.
4. **Methods.** By now you know which methods produced the results you are reporting.
5. **Discussion.** What the results mean, where they sit in the literature, and their limits.
6. **Related work.**
7. **Introduction.** You draft it early as a sketch, but you finish it late, once you know what the paper delivers.
8. **Conclusion.**
9. **Abstract.**
10. **Title.**

This order works because each step builds on the one before it. The introduction promises what the body delivers, so you write it after you know what the body delivers.

## 4. Figures carry the story

The *Why Your Research Paper Feels So Hard* video treats figures as the backbone of the paper. Its test is to print the figures, sit down with a colleague, and tell the story using only the figures. If you cannot tell a short, connected story, you do not have a paper yet. The order that works when you tell it out loud is the order for the paper. Any figure that does not fit the story goes, and it can go into another paper.

A figure is ready for publication when:

- It answers one question. You can say in one sentence what it shows.
- Axes have labels, units, and symbols, and panels are labelled A, B, C.
- All text is readable at the size it will print. Do not use software defaults; make a template.
- Variation stays visible. Show the error bars and the noise. Do not smooth noisy data to make it look clean.
- The caption works alone. A reader should understand the figure from the caption without going to the main text.
- Scales are honest. Do not start an axis at 10 instead of 0 to make a small effect look large, unless that is the convention in your field and you say so.
- It still makes sense printed in black and white.
- Every element is there for a reason. Remove anything that does no work.

## 5. Results

Once the figures are fixed, the results section almost writes itself. For each figure, write the bullet points of what it shows, then turn the bullets into a paragraph. Say what you measured, what you found, how many times you did it, and which figure shows it. Report null and negative results in the same plain way as positive ones.

Some fields combine results and discussion. In that case, follow each result with what it means. The video's example: "Interestingly, as the weight fraction increases, the sheet resistance reaches a minimum at..." The first half is the result and the "interestingly" half is the discussion.

## 6. Methods

The methods section should be boring and complete. The test is whether a competent stranger in your field can repeat exactly what you did without emailing you. Include:

- Who or what: participants and how you recruited them, materials and suppliers, models and versions, datasets.
- What you measured, and with which instruments or procedures.
- What analysis you ran, including the software and versions.
- Anything you chose not to do, and what you used instead.

Vague: "Students wore fitness trackers for a semester and we compared their sleep." Complete: how many students, how they were selected, which tracker, how many weeks, what was compared, and which grades were used.

## 7. The body: present the idea the way you would at a whiteboard

Peyton Jones's advice for the core technical sections comes from picturing a colleague in your office who has five minutes.

**Intuition comes first.** At a whiteboard you start with an example, never with a page of formal definitions. Do the same in the paper. Give the intuition, then the precise version. A reader who stops halfway should still leave with something useful.

**Do not walk the reader through your maze.** Research involves many dead ends. Do not recount them. Describe a blind alley only when it is the obvious approach and the reader needs to see why it fails before your approach makes sense.

**Every section supports a claim.** After the intuition, each section exists to provide evidence for one of the contributions you listed. Evidence can be a proof, measurements, an analysis, a comparison, or a case study. It should give the reader a reason to believe you, and enough detail to reproduce the result.

**Choose the detail level by the idea.** Space is limited. Include the details that explain the idea, and move loosely related material to an appendix, a technical report, or a later paper. An appendix works like a subroutine call. The reader gets the result in the main text and can look up the proof if they want it.

**Write section headings you would want to read.** You do not have to use the generic headings.

## 8. Discussion

The video gives the discussion four moves, in order:

1. Restate the key finding in plain numbers. "This study found that..."
2. Place it in the literature. Say what it extends, confirms, or contradicts.
3. Name the limitations honestly. They usually fall under measurement (for example, a proprietary algorithm whose internals you cannot see), design (for example, not a randomized trial), or population (for example, one student group).
4. Say what comes next. A well-stated limitation tells the reader what the next study should be.

Every result has a boundary on what the data lets you claim. Say where that boundary is.

## 9. Related work

**Where it goes.** Peyton Jones argues against a long related work section right after the introduction. At that point the reader lacks the vocabulary to follow a dense comparison, so the section either runs long or reads as cryptic, and it stands between the reader and your idea. His rule is to cite as you go and to compare at the end. While explaining the problem and your idea, cite prior work where it would come up naturally if you were explaining at a whiteboard ("the first approach you might try is X [cite]"). Hold the detailed comparison for a section near the end, once the reader knows your idea. Say in the introduction where that section is, so expert readers know you will get to it. Some venues and fields expect related work as section 2. Follow the venue if it is strict, but the cite-as-you-go rule still applies.

**Give credit generously.** Credit costs you nothing to give. Calling someone's paper "fascinating," when it is, does not make your work look smaller.

**Be honest about trade-offs.** Your approach is probably better on some axes and worse on others. Say where it is worse. That is good science, and it is also good tactics, because a reviewer who finds the weakness first will hold it against you.

**Leave out nothing important.** If a reviewer writes that the author seems unaware of a paper that does 80% of the same thing, the paper will probably be rejected. Never leave out a relevant paper in the hope that reviewers do not know it.

**Tool comparisons.** Let the data make the case. Describe the competing tool fairly, then show the table where yours does better.

## 10. The front matter: introduction, conclusion, abstract, title

Most people read the title. Fewer read the abstract, and fewer again read the first page. Put your effort where the readers are.

### Introduction

Aim to fit the problem, your idea, and your contributions on page one. Turning a page is a real hurdle for a reader.

The two sources describe the introduction differently, and the two descriptions combine well.

The video's funnel covers what goes in, from wide to narrow:

1. The field: what everyone already agrees on, with citations. Keep it short.
2. The gap, written as a problem with a cost.
3. The specific question that the gap makes worth asking, in one sentence.
4. What you did.

Peyton Jones adds rules for how to write it:

- **Do not open with general background.** Get to the problem within a few sentences. The funnel's first step should be two or three sentences long.
- **Show the problem with a concrete example.** A small program fragment, a data point, or a single case gets the reader engaged faster than an abstract description.
- **Pick a molehill, not a mountain.** "Computer programs have bugs, and this paper fixes them" tells the reader nothing, because nobody believes it. Choose a problem hard enough to be interesting and small enough to be solved.
- **List your contributions explicitly as bullets.** "We make the following contributions:" works well. Each contribution should be refutable, meaning you could fail to deliver it. "We study the properties of X" cannot fail. "We prove that type checking is decidable" can.
- **Give each contribution a forward reference** to the section that holds the evidence. This replaces the "The rest of this paper is organized as follows" paragraph, which nobody reads. It also helps you find sections that support no contribution and may not belong in the paper.

Readers who skim usually find the last paragraph of the introduction, the "In this paper we..." paragraph, and decide from it whether to read on. Make that paragraph specific.

### Conclusion

Keep it short. Readers are tired by the end. Do not copy the abstract into the past tense. State the main findings and what they mean, answer the question the paper set out to answer, and say how far the answer goes. Add no new information. If the conclusion needs a new fact, the results and discussion are missing something. If you include future work, keep it brief and frame it as directions you invite others to take up.

### Abstract

Write it last, from material that is already in the paper. The sources give two recipes.

The short recipe (Peyton Jones, from Kent Beck) is four sentences:

1. State the problem.
2. Say why it is an interesting problem.
3. Say what your solution achieves.
4. Say what follows from it.

The full recipe (from the video):

1. Context: often close to the first sentence of the introduction.
2. What you did.
3. The main result.
4. The nuance: where it did not hold.
5. The key number.
6. Meaning and boundary.

Use the full recipe when the venue allows a 150 to 250 word abstract and the paper has a quantitative result. Use the short one for tight limits. In either case, build it by pulling one sentence from each part of the paper and then smoothing them together. If the paper cannot supply those sentences, fix the paper before the abstract.

Do not repeat the abstract word for word in the introduction.

### Title

State the finding, not the topic. "Observation of gravitational waves from a binary black hole merger" is a good title. "A study investigating gravitational waves" is not. Titles that state the result are easier to find later in a reference manager, and readers can tell what to cite them for. The citations video reports studies finding that question titles get downloaded more but cited less. It also reports that humor can bring in readers, provided it does not hide the finding.

Include the keywords your field searches for, since search engines and reviewers bidding on papers often see only the title and abstract. Searching candidate keywords in Google Scholar shows you what readers will type.

## 11. Words and style

Use plain words. Jargon in the title and abstract is linked to fewer citations. If a smart non-specialist could not follow the abstract, simplify it. One check from the video: read the abstract into speech-to-text. If the software cannot recognize your words, readers will probably struggle with them too.

Keep acronyms few. Most acronyms in the literature are rarely reused. Define the ones you need and do not invent new ones without a reason.

Drop hype words. Words like "novel," "robust," "unprecedented," and "innovative" have become so common in papers that readers discount them. Describe what the result does and let the reader judge it.

Edit out machine-sounding prose. Prose that sounds machine-written loses readers' trust. Use the humanizer rules (github.com/blader/humanizer) as a final editing pass. They cover patterns such as "not X but Y" contrasts, one-line closers, forced lists of three, dashes everywhere, inflated significance, and decorative bold. Run it on prose only, and check afterwards that every number, citation, and claim survived.

### Where the sources disagree, and the rule this guide follows

| Topic | What the sources say | Rule here |
|---|---|---|
| When to write | Peyton Jones: write before the research is done. The videos: write after you have results, starting from results and figures. | Write the idea and contributions on day one. Write the body once results exist, figures first. |
| Introduction timing | Peyton Jones: draft the contributions list early. The videos: write the introduction last. | Sketch it early as a specification. Finish it late. |
| Related work position | Peyton Jones: near the end. The video's funnel cites the field at the start of the introduction. | Cite briefly in the introduction, compare in full near the end, unless the venue requires otherwise. |
| Title | Peyton Jones: a catchy title is worth a lot. The videos: state the finding, question titles get cited less, humor helps if it does not hide the finding. | State the finding with keywords. Humor is optional and never at the cost of clarity. |
| Abstract | Four sentences, or six moves. | Six moves by default, four for tight limits. |

## 12. Testing the draft on readers

**Ask readers where they got lost.** A friend who reads your draft will mark typos and grammar by default and will politely say nothing about the place where they got lost in section 3. Tell them before they start: "Don't fix my spelling. Show me where you got lost." Then sit with them, explain the confusing part out loud, and write down what you said. People explain things much better in speech than in writing, so the spoken explanation is usually what the paper needs.

**Use both non-experts and experts.** Non-experts find where the explanation is unclear. Experts find what is wrong or missing. One way to reach experts is to write to the authors you cite: "I've built on your paper and describe it in my related work section. Could you check I've described it fairly?" They often read more than that section. They may also end up as your reviewers, and criticism is cheaper at the draft stage. Do not send the draft to so many people that you use up all the likely reviewers.

**Read reviews after a week.** Rejection is normal, and reviews will often feel unfair at first. Put them away for a week. Then, for each misunderstanding, ask how to rewrite the paper so that no reviewer could make that mistake again. Reviewers are sometimes incompetent, but more often they are experts who misread something, and you can fix that.

## 13. Writing habits

The *How to Get More Citations* video covers the habits that get the writing done.

- **Name the block.** The usual ones are: "this draft is terrible" (allow a bad first draft), "I don't have a good idea yet" (good ideas come from working on bad ones), "I don't feel like it" (commit to two minutes), "this sentence has to be perfect" (it doesn't, and it will change in review anyway), "I'll start tomorrow" (do something small today), "I need a quiet place" (headphones work), and "I should tidy up first" (schedule tidying separately).
- **Schedule writing time and protect it.** Researchers who write in binges produce less and get fewer acceptances. Fixed blocks two or three times a week work better than a daily rule that you break. Studies of successful academics also find that their habits vary a lot, so use what works for you.
- **Have someone hold you to it.** A writing group or a colleague who asks on Friday how your writing went helps.

## 14. One-page checklist

Before you submit:

- [ ] I can state the paper's main idea in one sentence, and the paper states it.
- [ ] The problem appears on page one with a concrete example, and it is a molehill, not a mountain.
- [ ] Contributions are bulleted, refutable, and each has a forward reference to its evidence.
- [ ] There is no "the rest of this paper is organized as follows" paragraph.
- [ ] The technical sections lead with intuition and an example.
- [ ] Every section supports a listed contribution. Sections that support none have been cut or justified.
- [ ] A competent stranger could reproduce the methods without emailing me.
- [ ] Each figure answers one question, has a caption that works alone, readable text, honest scales, and visible variation.
- [ ] Null and negative results are reported.
- [ ] The discussion restates findings in numbers, places them in the literature, names limitations, and says what comes next.
- [ ] Related work gives generous credit, states honest trade-offs, and leaves out no closely related paper.
- [ ] The conclusion is short, adds nothing new, and does not copy the abstract.
- [ ] The abstract was built from sentences already in the paper and includes the key number and its limits.
- [ ] The title states the finding and contains the field's search keywords.
- [ ] No hype words, little jargon, and all acronyms defined.
- [ ] The humanizer pass is done, and all numbers and citations were rechecked after it.
- [ ] At least one reader told me where they got lost, and I fixed it.

## Sources

- Simon Peyton Jones, *How to Write a Great Research Paper*, Microsoft Research lecture.
- *How to Get More Citations*, YouTube video. The studies it cites are summarized here as reported in the video and have not been checked against the original papers.
- *Why Your Research Paper Feels So Hard*, YouTube video.
- Fred Brooks, *The Computer Scientist as Toolsmith II*, Communications of the ACM, 1996.
- blader/humanizer, github.com/blader/humanizer (MIT license).
