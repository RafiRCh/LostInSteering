# Paper-writing kit

This kit has two parts.

1. `guide/How_to_Write_a_Research_Paper.pdf` (also .md and .html) is the human-readable guide. It merges the writing advice from Simon Peyton Jones's talk and two YouTube guides.
2. `paper-writer/` is the skill. It runs the same method as a workflow for a Claude session (write, revise, brief another session, or draft a rebuttal), and it fetches the latest humanizer from github.com/blader/humanizer every time it loads. If GitHub cannot be reached, it uses the bundled v4.0.0 snapshot.

## Install the skill

- **Claude Code, one repository:** copy `paper-writer/` to `<repo>/.claude/skills/paper-writer/`.
- **Claude Code, all projects:** copy it to `~/.claude/skills/paper-writer/`.
- **claude.ai or the desktop app:** upload `paper-writer-skill.zip` under Settings > Capabilities > Skills.

To use it, ask for paper work ("draft the introduction", "write a brief for the results section") or invoke `/paper-writer`.

To check the live fetch by hand, run `python paper-writer/scripts/fetch_humanizer.py`.
